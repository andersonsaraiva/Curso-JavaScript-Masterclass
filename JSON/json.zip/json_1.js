JSON.stringify(10);
JSON.stringify("JavaScript");
JSON.stringify(true);
JSON.stringify(false);
JSON.stringify({name: "Self", paradigm: "OO"});
JSON.stringify([1,2,3,4,5,6,7,8,9]);
JSON.stringify(null);
