typeof 10;
typeof "JavaScript";
typeof true;
typeof Symbol("iterator");
typeof null;
typeof undefined;
