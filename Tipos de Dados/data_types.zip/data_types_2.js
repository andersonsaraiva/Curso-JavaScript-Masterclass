(10).toFixed(2);
('JavaScript').replace('a', '4');
(true).toString();
(Symbol("iterator")).toString();
