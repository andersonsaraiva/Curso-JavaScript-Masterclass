typeof function sum(a, b) {return a + b};
typeof {name: "Linus Torvalds"};
typeof [1,2,3,4,5,6];
typeof /[a-zA-Z]+/;
typeof (new Date());
