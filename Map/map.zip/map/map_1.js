const timeUnits = new Map();
console.log(timeUnits);
