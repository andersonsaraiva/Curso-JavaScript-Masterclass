const obj = {};
console.log("toString" in obj);
console.log("valueOf" in obj);
