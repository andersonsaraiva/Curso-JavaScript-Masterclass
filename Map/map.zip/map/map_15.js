const map = new Map();
console.log(map.get("toString"));
console.log(map.get("valueOf"));
