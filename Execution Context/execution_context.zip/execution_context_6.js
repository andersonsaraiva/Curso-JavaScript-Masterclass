const obj1 = {
    p1: 10,
    getP1: function() {
        return this.p1;
    }
};
console.log(obj1.getP1());
