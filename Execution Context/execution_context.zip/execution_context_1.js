const v1 = 10;
const fn1 = function() {
    console.log(v1);
};
fn1();
