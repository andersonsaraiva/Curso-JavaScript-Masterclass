let condition = new Boolean(false);
if (condition) {
    console.log("The condition is true");
} else {
    console.log("The condition is false");
}
