let condition = new Boolean(true);
if (condition) {
    console.log("The condition is true");
} else {
    console.log("The condition is false");
}
