!!0;
!!NaN;
!!"";
!!false;
!!undefined;
!!null;
