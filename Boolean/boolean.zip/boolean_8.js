!!-10;
!!"JavaScript";
!!{};
!![];
!!/JavaScript/;
!!new Date();
!!function () {};
