let condition = false;
if (condition) {
    console.log("The condition is true");
} else {
    console.log("The condition is false");
}
