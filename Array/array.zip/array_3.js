const timeUnits = new Array("minute", "hour", "day");
console.log(timeUnits);
