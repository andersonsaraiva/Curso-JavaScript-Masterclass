const timeUnits = ["minute", "hour", "day"];
console.log(timeUnits);
