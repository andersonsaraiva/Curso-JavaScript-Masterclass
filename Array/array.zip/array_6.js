const timeUnits = [];
timeUnits[0] = "minute";
timeUnits[1] = "hour";
timeUnits[2] = "day";
console.log(timeUnits);
console.log(timeUnits.length);
delete timeUnits[1];
console.log(timeUnits);
console.log(timeUnits.length);
