const languages = ["Python", "C", "Java"];
console.log(languages);
console.log(languages.unshift("Ruby"));
console.log(languages.unshift("Go"));
console.log(languages);
console.log(languages.shift());
console.log(languages.shift());
console.log(languages);
