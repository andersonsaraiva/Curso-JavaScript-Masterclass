const languages = ["Python", "C", "Java"];
languages.fill("JavaScript", 1);
console.log(languages);
