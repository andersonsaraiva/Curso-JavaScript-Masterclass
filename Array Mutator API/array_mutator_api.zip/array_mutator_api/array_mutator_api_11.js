const languages = ["Python", "C", "Java"];
languages.reverse();
console.log(languages);
languages.reverse();
console.log(languages);
