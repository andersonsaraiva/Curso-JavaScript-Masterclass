const languages = ["Python", "C", "Java"];
languages.fill("JavaScript");
console.log(languages);
