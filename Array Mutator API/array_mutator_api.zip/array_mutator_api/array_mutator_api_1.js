const languages = ["Python", "C", "Java"];
console.log(languages);
console.log(languages.push("Ruby"));
console.log(languages.push("Go"));
console.log(languages);
console.log(languages.pop());
console.log(languages.pop());
console.log(languages);
