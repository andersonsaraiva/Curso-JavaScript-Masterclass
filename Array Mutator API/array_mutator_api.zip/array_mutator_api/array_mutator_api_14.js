const languages = ["Python", "C", "Java"];
languages.fill("JavaScript", 0, 2);
console.log(languages);
