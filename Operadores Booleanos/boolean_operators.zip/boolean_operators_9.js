(10) ? 'good' : 'bad';
(0) ? 'good' : 'bad';
