0 == ''
0 == '0' 
false == undefined
false == null
null == undefined
1 == true
0 == false
0 == '\n'
