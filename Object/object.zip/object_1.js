{}
new Object();
Object.create(null);
