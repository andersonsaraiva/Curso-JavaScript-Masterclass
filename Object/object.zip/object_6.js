const book = {};
book.title = "Clean Code";
book.author = "Robert C. Martin";
book.pages = 464;
book.language = "English";
book.available = true;
console.log(book);
