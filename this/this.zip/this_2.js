const rectangle = {
    x: 10,
    y: 2,
    calculateArea() {
        return this.x * this.y;
    }
};
console.log(rectangle.calculateArea());
