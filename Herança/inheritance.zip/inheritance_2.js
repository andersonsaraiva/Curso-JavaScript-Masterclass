const functionalLanguage = {
    paradigm: "Functional"
};
const scheme = {
    name: "Scheme",
    year: 1975,
    paradigm: "Functional"    
};
const javascript = {
    name: "JavaScript",
    year: 1995,
    paradigm: "Functional"
};
console.log(functionalLanguage);
console.log(scheme);
console.log(javascript);
