10 * "JavaScript";
0/0;
Math.sqrt(-9);
Math.log(-1);
parseFloat("JavaScript");
