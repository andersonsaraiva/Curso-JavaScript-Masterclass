1/0;
Math.pow(10, 1000);
Number.MAX_VALUE * 2
Math.log(0);
-Number.MAX_VALUE * 2
