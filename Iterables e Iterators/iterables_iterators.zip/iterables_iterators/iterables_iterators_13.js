let language = "COBOL";
for (let char of language) {
    console.log(char);
}
