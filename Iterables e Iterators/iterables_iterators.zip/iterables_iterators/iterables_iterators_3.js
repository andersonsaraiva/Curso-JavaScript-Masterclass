const languages = ["Fortran", "Lisp", "COBOL"];
languages.forEach(function (language) {
    console.log(language);
});
