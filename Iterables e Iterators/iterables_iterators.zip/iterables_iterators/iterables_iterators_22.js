const languages = new Set(["Fortran", "Lisp", "COBOL"]);
const iterator = languages.keys();
console.log(iterator.next());
console.log(iterator.next());
console.log(iterator.next());
console.log(iterator.next());
