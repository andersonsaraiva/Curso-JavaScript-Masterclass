let language = "COBOL";
console.log([...language]);
