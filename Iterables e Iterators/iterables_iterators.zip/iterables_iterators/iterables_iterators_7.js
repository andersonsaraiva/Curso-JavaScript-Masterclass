const classicLanguages = ["Fortran", "Lisp", "COBOL"];
const modernLanguages = ["Python", "Ruby", "JavaScript"]
const languages = [...classicLanguages, ...modernLanguages];
console.log(languages);
