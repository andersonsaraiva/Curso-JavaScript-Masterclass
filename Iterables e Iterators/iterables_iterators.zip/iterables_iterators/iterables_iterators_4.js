const languages = ["Fortran", "Lisp", "COBOL"];
languages.forEach((language) => {
    console.log(language);
});
