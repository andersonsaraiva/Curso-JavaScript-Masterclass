const languages = new Map([["Fortran", 1957], ["Lisp", 1958], ["COBOL", 1959]]);
console.log([...languages]);
