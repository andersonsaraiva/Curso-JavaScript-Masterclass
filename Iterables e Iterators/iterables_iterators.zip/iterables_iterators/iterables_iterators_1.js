const languages = ["Fortran", "Lisp", "COBOL"];
for (let i = 0; i < languages.length; i++) {
    console.log(languages[i]);
}
