let languages = new Set(["Fortran", "Lisp", "COBOL"]);
for (let language of languages) {
    console.log(language);
}
