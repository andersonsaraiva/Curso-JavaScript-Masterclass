const languages = ["Fortran", "Lisp", "COBOL"];
for (let i in languages) {
    console.log(languages[i]);
}
