const languages = new Set(["Fortran", "Lisp", "COBOL"]);
const iterator = languages.values();
console.log(iterator.next());
console.log(iterator.next());
console.log(iterator.next());
console.log(iterator.next());
