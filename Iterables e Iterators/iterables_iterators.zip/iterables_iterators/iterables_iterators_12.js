let languages = new Set(["Fortran", "Lisp", "COBOL"]);
console.log([...languages]);
