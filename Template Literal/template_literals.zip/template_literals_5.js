let monthsOfYear = "0 - Jan\n\
1 - Feb\n\
2 - Mar\n\
3 - Apr\n\
4 - May\n\
5 - Jun\n\
6 - Jul\n\
7 - Aug\n\
8 - Sep\n\
9 - Oct\n\
10 - Nov\n\
11 - Dec";
console.log(monthsOfYear);
