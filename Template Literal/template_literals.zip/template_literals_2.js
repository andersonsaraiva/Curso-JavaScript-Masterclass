let host = "localhost";
let port = "3000";
let resource = "users";
let url = `https://${host}:${port}/${resource}`;
console.log(url);
