const circle = new Circle(10);
console.log(circle);
console.log(circle.area);
import Circle from './circle';
