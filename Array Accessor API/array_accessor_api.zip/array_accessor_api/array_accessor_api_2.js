const languages = ["Python", "C", "Java"];
console.log(languages.includes("Python"));
console.log(languages.includes("C"));
console.log(languages.includes("JavaScript"));
