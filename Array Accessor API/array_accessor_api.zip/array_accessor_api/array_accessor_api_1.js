const languages = ["Python", "C", "Java"];
console.log(languages.indexOf("Python"));
console.log(languages.lastIndexOf("C"));
console.log(languages.indexOf("JavaScript"));
