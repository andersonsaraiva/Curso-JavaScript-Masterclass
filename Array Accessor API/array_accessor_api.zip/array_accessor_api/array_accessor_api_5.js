const languages = ["Smalltalk", "C++", "Simula", "Haskell", "Scheme"];
console.log(languages.join(","));
console.log(languages.join(";"))
console.log(languages.join(" "))
