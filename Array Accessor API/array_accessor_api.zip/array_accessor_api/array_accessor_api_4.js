const languages = ["Smalltalk", "C++", "Simula", "Haskell", "Scheme"];
console.log(languages.slice(0, 2));
console.log(languages.slice(2, 4));
console.log(languages.slice(1));
