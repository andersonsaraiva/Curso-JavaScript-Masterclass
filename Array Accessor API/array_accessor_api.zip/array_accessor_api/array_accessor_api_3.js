const ooLanguages = ["Smalltalk", "C++", "Simula"];
const functionalLanguages = ["Haskell", "Scheme"];
console.log(ooLanguages.concat(functionalLanguages));
console.log(ooLanguages);
console.log(functionalLanguages);
