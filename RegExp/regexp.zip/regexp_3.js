let regExp = /john@gmail.com/;
let result = regExp.test("john@gmail.com");
console.log(result);
