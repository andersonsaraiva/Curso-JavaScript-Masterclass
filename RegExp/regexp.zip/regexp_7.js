let regExp = /john@gmail\.com/;
let result = regExp.exec("E-Mail: john@gmailxcom");
console.log(result);
