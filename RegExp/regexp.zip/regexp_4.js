let regExp = /john@gmail.com/;
let result = regExp.exec("john@gmail.com");
console.log(result);
