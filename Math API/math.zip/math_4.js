Math.min(1,2,3,4,5,6);
Math.max(1,2,3,4,5,6);
Math.random();
