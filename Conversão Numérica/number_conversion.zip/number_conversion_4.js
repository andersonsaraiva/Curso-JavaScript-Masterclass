(0xA).toString(10);
(0b1010).toString(16);
(010).toString(2);
(10).toString(8);
