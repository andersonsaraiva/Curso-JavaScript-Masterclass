parseInt("10", 10);
parseInt("9.9", 10);
parseInt("A", 16);
parseInt("11", 2);
parseInt("010", 8);
