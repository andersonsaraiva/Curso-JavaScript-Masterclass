Number("10");
Number("9.9");
Number("0xFF");
Number("0b10");
Number("0o10");
Number();
Number("JavaScript");
