parseFloat("10");
parseFloat("2.5");
parseFloat("0xFF");
parseFloat("0b10");
