function sum(a, b) {
    return a + b;
}
const result = sum(2, 2);
console.log(result);
