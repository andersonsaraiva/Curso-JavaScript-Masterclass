new Number(10);
new Number(9.9);
new Number(0xFF);
new Number(0b10);
new Number(0o10);
