(123.4).toExponential(10);
(123.4).toFixed(10);
(123.4).toPrecision(10);
