const square = new Square();
class Square {
}
console.log(square);
