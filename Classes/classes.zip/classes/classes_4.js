const Square = class {
}
const square = new Square();
console.log(square);
