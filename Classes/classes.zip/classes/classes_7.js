class Square {
    constructor() {
    }
}
const square = new Square();
console.log(square);
