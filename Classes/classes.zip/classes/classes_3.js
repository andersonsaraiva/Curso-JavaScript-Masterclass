const Square = class {
}
console.log(typeof Square);
