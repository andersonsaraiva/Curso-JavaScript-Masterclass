const square = new Square();
const Square = class {
}
console.log(square);
