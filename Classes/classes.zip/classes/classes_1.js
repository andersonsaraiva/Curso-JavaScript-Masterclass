class Square {
}
console.log(Square);
