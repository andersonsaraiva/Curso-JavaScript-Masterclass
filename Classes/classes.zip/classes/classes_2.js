const Square = class {
}
console.log(Square);
