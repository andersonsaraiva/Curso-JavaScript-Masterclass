const wm1 = new WeakMap();
console.log(wm1);
