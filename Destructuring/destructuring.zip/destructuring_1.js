const language = "C;Dennis Ritchie;1972".split(";");
const name = language[0];
const author = language[1];
const year = language[2];
console.log(name, author, year);
