function sum({a, b}) {
    return a + b;
}
console.log(sum({a: 2, b: 2}));
