const [name, author, year] = "C;Dennis Ritchie;1972".split(";");
console.log(name, author, year);
