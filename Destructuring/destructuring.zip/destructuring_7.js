const language = {
    name: "C",
    author: "Dennis Ritchie",
    year: 1972
};
const name = language.name;
const author = language.author;
const year = language.year;
console.log(name, author, year);
