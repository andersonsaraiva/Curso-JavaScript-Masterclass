const language = {
    name: "C",
    author: "Dennis Ritchie",
    year: 1972
};
const {name: n, author: a, year: y} = language;
console.log(n, a, y);
