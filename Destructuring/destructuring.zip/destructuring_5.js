const language = "C;Dennis Ritchie;1972".split(";");
const [name = "-", author = "-", year = "-"] = language;
console.log(name, author, year);
