const [, author, year] = "C;Dennis Ritchie;1972".split(";");
console.log(author, year);
