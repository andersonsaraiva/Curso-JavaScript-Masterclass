const javascript1 = {
    name: "JavaScript",
    year: 1995,
    paradigm: "OO and Functional"
};
const javascript2 = {
    name: "JavaScript",
    year: 1995,
    paradigm: "OO and Functional"
};
console.log(Object.is(javascript1, javascript2));
