console.log(Object.is(NaN, NaN));
