new String('JavaScript');
new String("JavaScript");
new String(`JavaScript`);
