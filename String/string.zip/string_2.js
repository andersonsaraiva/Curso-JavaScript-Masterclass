'JavaScript' === "JavaScript";
'JavaScript' === `JavaScript`;
"JavaScript" === `JavaScript`;
