let result = 10;
result++;
++result;
result--;
--result;
