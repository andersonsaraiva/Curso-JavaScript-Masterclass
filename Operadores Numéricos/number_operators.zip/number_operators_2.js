let result = 10;
result += 2;
result -= 5;
result *= 8;
result /= 2;
result %= 6;
