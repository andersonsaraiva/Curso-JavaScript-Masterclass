console.log(sum(2, 2));
const sum = function(a, b) {
    return a + b;
}
