function sum(a = 1, b = 1) {
    return a + b;
}
console.log(sum(2, 2));
console.log(sum(5));
console.log(sum());
