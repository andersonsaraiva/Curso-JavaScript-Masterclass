console.log(sum(2, 2));
function sum(a, b) {
    return a + b;
}
