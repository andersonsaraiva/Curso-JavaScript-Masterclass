function sum(a, b) {
    return a + b;
}
console.log(sum(2, 2));
console.log(sum(5));
console.log(sum(1, 2, 3));
