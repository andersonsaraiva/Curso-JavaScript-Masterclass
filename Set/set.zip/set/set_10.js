const array = [];
array.push(10);
array.push(10);
array.push(10);
console.log(array);
console.log(array.length);
