const charsets = new Set();
console.log(charsets);
