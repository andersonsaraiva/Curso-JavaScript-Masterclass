const set = new Set();
set.add("10");
set.add("10");
set.add("10");
console.log(set);
console.log(set.size);
