const charsets = new Set(["ASCII", "ISO-8599-1", "UTF-8"]);
console.log(charsets);
console.log(charsets.size);
