const ws1 = new WeakSet();
console.log(ws1);
