"JavaScript".includes("Java");
"Ruby".startsWith("R");
"Erlang".endsWith("lang");
