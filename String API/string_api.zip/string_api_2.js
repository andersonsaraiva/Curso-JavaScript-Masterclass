"JavaScript".charAt(1);
"JavaScript".charCodeAt(1);
String.fromCharCode(97);
