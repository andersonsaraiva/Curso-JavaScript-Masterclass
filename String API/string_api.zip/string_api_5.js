"C++".match(/\+/g);
"Java".search(/a/);
"JavaScript".replace("Java", "Ecma");
"JavaScript".replace(/a/g, 4);
