"JavaScript".slice(0, 4);
"JavaScript".slice(4);
"JavaScript".slice(0, -6);
"JavaScript".slice(-6);
"C;Java;JavaScript;Ruby".split(";");
"JavaScript".substring(0, 4);
"JavaScript".substring(4, 0);
"JavaScript".substring(4);
