"JavaScript".length;
"PHP".indexOf("P");
"PHP".lastIndexOf("P");
"cobol".toUpperCase();
"ALGOL".toLowerCase();
