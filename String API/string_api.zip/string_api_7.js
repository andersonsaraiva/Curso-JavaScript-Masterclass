"Java".concat("Script");
"Data".concat("Flex");
"Script".padStart(10, "Java");
"C".padEnd(3, "+");
"C".concat("+".repeat(2));
" Self ".trim();
" Scheme ".trimLeft();
" Perl ".trimRight();
