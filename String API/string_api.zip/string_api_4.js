"C++".localeCompare("Ruby");
"Python".localeCompare("Java");
"JavaScript".localeCompare("JavaScript");
